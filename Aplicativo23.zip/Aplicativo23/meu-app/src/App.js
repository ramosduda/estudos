import Header from "./componentes/Header/Header";
import Footer from "./componentes/Footer/Footer";
import "./style.css"
import Nav from "./componentes/Nav/Nav";
import Home from "./pagina/Home/Home";


function App() {

  function reproduzVideo() {
    alert("O vídeo está sendo reproduzido")
}

  return (
    <body>
    <div class="tela-inteira">
      <Header/>

        <main>
            
            <Nav/>

            <Home reprouz={reproduzVideo}/>
        </main>

        <Footer/>

    </div>
</body>
    
  );
}

export default App;
