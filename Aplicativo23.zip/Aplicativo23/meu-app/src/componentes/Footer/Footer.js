function Footer(){

    return(
        <footer>
            <h4>Oi! Eu moro no footer!</h4>
        </footer>
    )
}

export default Footer