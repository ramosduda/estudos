import styled, { createGlobalStyle } from "styled-components";
import (createGlobalStyle)

export default createGlobalStyle`
    margin: 0;
    padding: 0;
    box-sizing: border-box;
`

export const TelaInicial = styled.div`
    heigh: 100vh;
    display: flex;
    flex-direction: coluns;
`

export const ContainerMain = styled.div`
    min-heignt: 95vh;
    display: flex;
`